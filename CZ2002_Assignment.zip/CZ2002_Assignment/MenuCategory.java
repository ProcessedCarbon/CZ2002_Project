package CZ2002_Assignment;

public enum MenuCategory {
	DRINKS, MAINS, SIDES, DESSERTS;
}
